const users = [
    { nama: 'john' umur: 30, alamat: 'Jakarta' },
    { nama: 'jane' umur: 25, alamat: 'Bandung' },
    { nama: 'joe' umur: 35, alamat: 'Surabaya' },
    { nama: 'jenny' umur: 20, alamat: 'Malang' },
    { nama: 'jack' umur: 40, alamat: 'Yogyakarta' },
    { nama: 'jessy' umur: 28, alamat: 'Semarang' },
    { nama: 'jason' umur: 32, alamat: 'Bogor' },
    { nama: 'julia' umur: 22, alamat: 'Denpasar' },
    { nama: 'jerry' umur: 38, alamat: 'Palembang' },
    { nama: 'jessie' umur: 26, alamat: 'Pontianak' },
]

export default users;