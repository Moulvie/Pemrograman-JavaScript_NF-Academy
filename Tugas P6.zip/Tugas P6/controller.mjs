import users from "./data.mjs"

const index() {
    console.log("Daftar Pengguna:");
    users.forEach(({ nama, umur, alamat }) => {
        console.log(`nama: ${nama}, Umur: ${umur}, Alamat: ${alamat}`)
}}

const store = (newDatauser) => {
    users.push(newDatauser);
    console.log("Data Pengguna telah ditambahkan");

}

const destroy = (index) => {
    if (index >= 0 && index < users.length) {
        users.splice(index, 1);
        console.log("Data Pengguna telah dihapus");

    } else {
        console.log("Index tidak valid");
    }
}

export { index, store, destroy}